/*
	TCP Echo Standard Client Demo (Multiprocess Concurrency)
	Copyright@2020 张翔（zhangx@uestc.edu.cn）All Right Reserved
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_CMD_STR 100
#define bprintf(fp, format, ...) \
	if(fp == NULL){printf(format, ##__VA_ARGS__);} 	\
	else{printf(format, ##__VA_ARGS__);	\
			fprintf(fp, format, ##__VA_ARGS__);fflush(fp);}

int sig_type = 0;
FILE * fp_res = NULL;

void sig_pipe(int signo) {
	sig_type = signo;
	pid_t pid = getpid();
	bprintf(fp_res, "[cli](%d) SIGPIPE is coming!\n", pid);	
}
void sig_chld(int signo) {
    sig_type = signo;
	pid_t pid = getpid(), pid_chld = 0;
    int stat; 

	bprintf(fp_res, "[cli](%d) SIGCHLD is coming!\n", pid);
    while ((pid_chld = waitpid(-1, &stat, WNOHANG)) > 0){
		bprintf(fp_res, "[cli](%d) child process(%d) terminated.\n", pid, pid_chld);
	}
}

int echo_rqt(int sockfd, int pin)
{
	pid_t pid = getpid();
	// PDU定义：PIN LEN Data
	int len_h = 0, len_n = 0;
	int pin_h = pin, pin_n = htonl(pin);
	char fn_td[10] = {0};
	char buf[MAX_CMD_STR+1+8] = {0}; //定义应用层PDU缓存

	sprintf(fn_td, "td%d.txt", pin);
	FILE * fp_td = fopen(fn_td, "r");
	if(!fp_td){
		bprintf(fp_res, "[cli](%d) Test data read error!\n", pin_h);
		return 0;
	}

    // 读取一行测试数据，从编址buf+8的字节开始写入，前8个字节分别留给PIN与数据长度（均为int）
    while (fgets(buf+8, MAX_CMD_STR, fp_td)) {
	// 重置pin_h & pin_n:
		pin_h = pin;
		pin_n = htonl(pin);
	// 指令解析:
		// 收到指令"exit"，跳出循环并返回
		if(strncmp(buf+8, "exit", 4) == 0){
			// printf("[cli](%d) \"exit\" is found!\n", pin_h);
			break;
		}

	// 数据解析（构建应用层PDU）:
		// 将PIN写入PDU缓存（网络字节序）
		memcpy(buf, &pin_n, 4);
		// 获取数据长度
		len_h = strnlen(buf+8, MAX_CMD_STR);
		// 将数据长度写入PDU缓存（网络字节序）
		len_n = htonl(len_h);
		memcpy(buf+4, &len_n, 4);
		// 将读入的'\n'更换为'\0'；若仅有'\n'输入，则'\0'将被作为数据内容发出，数据长度为1
		if(buf[len_h+8-1] == '\n')
			buf[len_h+8-1] = 0; // 同'\0'

	// 发送echo_rqt数据:
        write(sockfd, buf, len_h+8);
    
	// 读取echo_rep数据:
		memset(buf, 0, sizeof(buf));
		// 读取PIN（网络字节序）
        read(sockfd, &pin_n, 4);
		// 读取服务器echo_rep数据长度（网络字节序）并转为主机字节序
		read(sockfd, &len_n, 4);
		len_h = ntohl(len_n);
		// 读取服务器echo_rep数据
        read(sockfd, buf, len_h);
		bprintf(fp_res,"[echo_rep](%d) %s\n", pid, buf);
    }
	return 0;
}

int main(int argc, char* argv[])
{
	// 基于argc简单判断命令行指令输入是否正确；
	if(argc != 4){
		printf("Usage:%s <IP> <PORT> <CONCURRENT AMOUNT>\n", argv[0]);
		return 0;
	}

	struct sigaction sigact_pipe, old_sigact_pipe;
	sigact_pipe.sa_handler = sig_pipe;//sig_pipe()，信号处理函数
	sigemptyset(&sigact_pipe.sa_mask);
	sigact_pipe.sa_flags = 0;
	sigact_pipe.sa_flags |= SA_RESTART;//设置受影响的慢系统调用重启
	sigaction(SIGPIPE, &sigact_pipe, &old_sigact_pipe);

	struct sigaction sigact_chld, old_sigact_chld;
    sigact_chld.sa_handler = &sig_chld;
    sigemptyset(&sigact_chld.sa_mask);
    sigact_pipe.sa_flags = 0;
	sigact_pipe.sa_flags |= SA_RESTART;//设置受影响的慢系统调用重启
    sigaction(SIGCHLD, &sigact_chld, &old_sigact_chld);

	struct sockaddr_in srv_addr;
	struct sockaddr_in cli_addr;
	int cli_addr_len;
	int connfd;
	int conc_amnt = atoi(argv[3]);

	// 获取当前进程PID，用于后续父进程信息打印；
	pid_t pid = getpid();

	// Initialize address
	memset(&srv_addr, 0, sizeof(srv_addr));
	srv_addr.sin_family = AF_INET;
	inet_pton(AF_INET, argv[1], &srv_addr.sin_addr);
	srv_addr.sin_port = htons(atoi(argv[2]));

	for (int i = 0; i < conc_amnt - 1; i++) {
        if (!fork()) {// 子进程
			int pin = i+1;
			char fn_res[20];
			
			// 获取当前子进程PID,用于后续子进程信息打印
			pid = getpid();
			
			// 打开res文件，文件序号指定为当前子进程序号PIN；
			sprintf(fn_res, "stu_cli_res_%d.txt", pin);
        	fp_res = fopen(fn_res, "ab"); // Write only， append at the tail. Open or create a binary file;
			if(!fp_res){
				printf("[cli](%d) child exits, failed to open file \"stu_cli_res_%d.txt\"!\n", pid, pin);
				exit(-1);
			}

			bprintf(fp_res, "[cli](%d) child process %d is created!\n", pid, pin);
			
			connfd = socket(PF_INET, SOCK_STREAM, 0);
			// TODO If socket() fail.
			do{
				int res = connect(connfd, (struct sockaddr*) &srv_addr, sizeof(srv_addr));
				if(!res){
					char ip_str[20]={0};
					bprintf(fp_res, "[cli](%d) server[%s:%d] is connected!\n", pid, \
						inet_ntop(AF_INET, &srv_addr.sin_addr, ip_str, sizeof(ip_str)), \
							ntohs(srv_addr.sin_port));
					if(!echo_rqt(connfd, pin))
						break;
				}
				else
					break;	
			}while(1);

			// 关闭连接描述符
			close(connfd);
			bprintf(fp_res, "[cli](%d) connfd is closed!\n", pid);
			bprintf(fp_res, "[cli](%d) child process is going to exit!\n", pid);
			
			// 关闭子进程res文件
			if(fp_res){
				if(!fclose(fp_res))
					printf("[cli](%d) stu_cli_res_%d.txt is closed!\n", pid, pin);
			}
			exit(1);
		}
		else{// 父进程
			close(connfd);
			continue;
		}	
	}
	

	char fn_res[20];
	sprintf(fn_res, "stu_cli_res_%d.txt", 0);
    fp_res = fopen(fn_res, "wb");
	if(!fp_res){
		printf("[cli](%d) child exits, failed to open file \"stu_cli_res_0.txt\"!\n", pid);
		exit(-1);
	}

	//creat client fd
	connfd = socket(PF_INET, SOCK_STREAM, 0);
	//connect client to server
	do{
		int res = connect(connfd, (struct sockaddr*) &srv_addr, sizeof(srv_addr));
		if(!res){
			char ip_str[20]={0};
			bprintf(fp_res, "[cli](%d) server[%s:%d] is connected!\n", pid, inet_ntop(AF_INET, &srv_addr.sin_addr, ip_str, sizeof(ip_str)), ntohs(srv_addr.sin_port));
			if(!echo_rqt(connfd, 0))
				break;
		}
		else
			break;
	}while(1);

	// 关闭连接描述符
	close(connfd);
	bprintf(fp_res, "[cli](%d) connfd is closed!\n", pid);
	bprintf(fp_res, "[cli](%d) parent process is going to exit!\n", pid);

	// 关闭父进程res文件
	if(!fclose(fp_res))
		printf("[cli](%d) stu_cli_res_0.txt is closed!\n", pid);
		
	return 0;
}