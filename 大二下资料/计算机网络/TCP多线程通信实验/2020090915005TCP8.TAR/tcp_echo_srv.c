#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>
#include <assert.h>

#define BACKLOG 1024
#define bprintf(fp, format, ...) \
	if(fp == NULL){printf(format, ##__VA_ARGS__);} 	\
	else{printf(format, ##__VA_ARGS__);	\
			fprintf(fp, format, ##__VA_ARGS__);fflush(fp);}

int signal_type = 0, signal_to_exit = 0;
FILE * fpRes = NULL;

void sig_int(int signoll) {	
	signal_type = signoll;
	pid_t pid = getpid();
	bprintf(fpRes, "[srv](%d) SIGINT is coming!\n", pid);
    signal_to_exit = 1;
}
void sig_pipe(int signoll) {	
	signal_type = signoll;
	pid_t pid = getpid();
	bprintf(fpRes, "[srv](%d) SIGPIPE is coming!\n", pid);
}
void sig_chld(int signoll) {
    signal_type = signoll;
	pid_t pid = getpid(), pid_chld = 0;
    int stat; 

	bprintf(fpRes, "[srv](%d) SIGCHLD is coming!\n", pid);
	while ((pid_chld = waitpid(-1, &stat, WNOHANG)) > 0){
		//bprintf(fpRes, "[srv](%d) child process(%d) terminated.\n", pid, pid_chld);
	}
}
int install_sig_handlers(){
	int res = -1;
	struct sigaction sigact_pipe, old_sigact_pipe;
	sigact_pipe.sa_handler = sig_pipe;
	sigact_pipe.sa_flags = 0;
	sigact_pipe.sa_flags |= SA_RESTART;
	sigemptyset(&sigact_pipe.sa_mask);
	res = sigaction(SIGPIPE, &sigact_pipe, &old_sigact_pipe);
	if(res)
		return -1;

	struct sigaction sigact_chld, old_sigact_chld;
    // sigact_chld.sa_handler = SIG_IGN; 
	sigact_chld.sa_handler = sig_chld;
    sigact_pipe.sa_flags = 0;
	sigact_pipe.sa_flags |= SA_RESTART;
	sigemptyset(&sigact_chld.sa_mask);
    res = sigaction(SIGCHLD, &sigact_chld, &old_sigact_chld);
	if(res)
		return -2;
	
	struct sigaction sigact_int, old_sigact_int;
    sigemptyset(&sigact_int.sa_mask);
    sigact_int.sa_flags = 0;
	sigact_int.sa_handler = &sig_int;
    sigaction(SIGINT, &sigact_int, &old_sigact_int);
	if(res)
		return -3;

	return 0;
}

int echo_rep(int sockfd)
{
	int length_host = -1, length_network = -1;
	int pin_host = -1, pin_network = -1;
	int res = 0;
	char *buffer = NULL;
	pid_t pid = getpid();
    do {
		do{
			res = read(sockfd, &pin_network, sizeof(pin_network));
			if(res < 0){
				bprintf(fpRes, "[srv](%d) read pin_network return %d and errno is %d!\n", pid, res, errno);
				if(errno == EINTR){
					if(signal_type == SIGINT)
						return pin_host;
					continue;
				}
				return pin_host;
			}
			if(!res){
				return pin_host;
			}
			pin_host = ntohl(pin_network); 
			break;				
		}while(1);
		do{
			res = read(sockfd, &length_network, sizeof(length_network));
			if(res < 0){
				bprintf(fpRes, "[srv](%d) read length_network return %d and errno is %d\n", pid, res, errno);
				if(errno == EINTR){
					if(signal_type == SIGINT)
						return pin_host;
					continue;
				}
				return pin_host;
			}
			if(!res){
				return pin_host;
			}
			length_host = ntohl(length_network); 
			break;
		}while(1);
		int read_amnt = 0, len_to_read = length_host;
		buffer = (char*)malloc(length_host * sizeof(char)+8); 
		do{
			res = read(sockfd, buffer+8+read_amnt, len_to_read);
			if(res < 0){
				bprintf(fpRes, "[srv](%d) read data return %d and errno is %d,\n", pid, res, errno);
				if(errno == EINTR){
					if(signal_type == SIGINT){
						free(buffer);
						return pin_host;
					}
					continue;
				}
				free(buffer);
				return pin_host;
			}
			if(!res){
				free(buffer);
				return pin_host;
			}

			read_amnt += res;
			if(read_amnt == length_host){
				break;
			}
			else if(read_amnt < length_host){
				len_to_read = length_host - read_amnt;
			}
			else{
				free(buffer);
				return pin_host;
			}
		}while(1);
		bprintf(fpRes, "[echo_rqt](%d) %s\n", pid, buffer+8);
		memcpy(buffer, &pin_network, 4);
		memcpy(buffer+4, &length_network, 4);
		write(sockfd, buffer, length_host+8);
        free(buffer);
    }while(1);
	return pin_host;
}

int main(int argc, char* argv[])
{
	if(argc != 3)
	{
		printf("Usage:%s <IP> <PORT>\n", argv[0]);
		return -1;
	}

	pid_t pid = getpid();
	char ip_string[20]={0};
	char fnRes[20]={0};//
	int res = -1;
	res = install_sig_handlers();
	if(res){
		printf("[srv](%d) parent exit failed to install signal handlers!\n", pid);
		return res;
	}
	fpRes = fopen("stu_srv_res_p.txt", "wb");
	if(!fpRes){
		printf("[srv](%d) failed to open file \"stu_srv_res_p.txt\"!\n", pid);
		return res;
	}
	struct sockaddr_in srv_addr, cli_addr;
	socklen_t client_address_length;
	int listenfd, connectionfd;
	bzero(&srv_addr, sizeof(srv_addr));
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.s_addr = inet_addr(argv[1]);
	srv_addr.sin_port = htons(atoi(argv[2]));
	inet_ntop(AF_INET, &srv_addr.sin_addr, ip_string, sizeof(ip_string));
	bprintf(fpRes, "[srv](%d) server[%s:%d] is initializing!\n", pid, ip_string, (int)ntohs(srv_addr.sin_port));
	listenfd = socket(PF_INET, SOCK_STREAM, 0);	
	if(listenfd == -1)
		return listenfd;
	res = bind(listenfd, (struct sockaddr*)&srv_addr, sizeof(srv_addr));
	if(res)
		return res;
	res = -9;
	res = listen(listenfd,BACKLOG);
	if(res)
		printf("[srv](%d) listen() returned %d\n", pid, res);
	else if(res == 0)
		printf("[srv](%d) listen() returned 0\n",pid);
	while(!signal_to_exit)
	{
		client_address_length = sizeof(cli_addr);
		connectionfd = accept(listenfd, (struct sockaddr*)&cli_addr, &client_address_length);
		if(connectionfd == -1 && errno == EINTR){
			if(signal_type == SIGINT)
				break;
			continue;
		}
		inet_ntop(AF_INET, &cli_addr.sin_addr, ip_string, sizeof(ip_string));
		bprintf(fpRes, "[srv](%d) client[%s:%d] is accepted!\n", pid, ip_string, (int)ntohs(cli_addr.sin_port));
		fflush(fpRes);

		if(!fork()){

			pid = getpid();
			sprintf(fnRes, "stu_srv_res_%d.txt", pid);
			fpRes = fopen(fnRes, "wb");
			if(!fpRes){
				printf("[srv](%d) child exits, failed to open file \"stu_srv_res_%d.txt\"!\n", pid, pid);
				exit(-1);
			}

			bprintf(fpRes, "[srv](%d) child process is created!\n", pid);
			close(listenfd);
			bprintf(fpRes, "[srv](%d) listenfd is closed!\n", pid);
			int pin = echo_rep(connectionfd);
			if(pin < 0){
				bprintf(fpRes, "[srv](%d) child exits, client PIN returned by echo_rqt() error!\n", pid);
				exit(-1);
			}
			char fnRes_n[20]={0};
			sprintf(fnRes_n, "stu_srv_res_%d.txt", pin);
			if(!rename(fnRes, fnRes_n)){
				bprintf(fpRes, "[srv](%d) res file rename done!\n", pid);
			}
			else{			
				bprintf(fpRes, "[srv](%d) child exits, res file rename failed!\n", pid);
			}
			close(connectionfd);
			bprintf(fpRes, "[srv](%d) connectionfd is closed!\n", pid);
			bprintf(fpRes, "[srv](%d) child process is going to exit!\n", pid);
			if(!fclose(fpRes))
				printf("[srv](%d) stu_srv_res_%d.txt is closed!\n", pid, pin);

			exit(1);
		}
		else{	
			close(connectionfd);
			continue;
		}
	}

	close(listenfd);
	bprintf(fpRes, "[srv](%d) listenfd is closed!\n", pid);
	bprintf(fpRes, "[srv](%d) parent process is going to exit!\n", pid);

	if(!fclose(fpRes))
		printf("[srv](%d) stu_srv_res_p.txt is closed!\n", pid);

	return 0;
}