#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_CMD_STR 100
#define bprintf(fp, format, ...) \
	if(fp == NULL){printf(format, ##__VA_ARGS__);} 	\
	else{printf(format, ##__VA_ARGS__);	\
			fprintf(fp, format, ##__VA_ARGS__);fflush(fp);}

int signal_type = 0;
FILE * fpRes = NULL;

void sig_pipe(int signoll) {
	signal_type = signoll;
	pid_t pid = getpid();
	bprintf(fpRes, "[cli](%d) SIGPIPE is coming!\n", pid);	
}
void sig_chld(int signoll) {
    signal_type = signoll;
	pid_t pid = getpid(), pid_chld = 0;
    int stat; 

	bprintf(fpRes, "[cli](%d) SIGCHLD is coming!\n", pid);
    while ((pid_chld = waitpid(-1, &stat, WNOHANG)) > 0){
		bprintf(fpRes, "[cli](%d) child process(%d) terminated.\n", pid, pid_chld);
	}
}

int echo_rqt(int sockfd, int pin)
{
	pid_t pid = getpid();
	int length_host = 0, length_network = 0;
	int pin_host = pin, pin_network = htonl(pin);
	char filename_td[10] = {0};
	char buffer[MAX_CMD_STR+1+8] = {0}; 

	sprintf(filename_td, "td%d.txt", pin);
	FILE * filepoint_td = fopen(filename_td, "r");
	if(!filepoint_td){
		bprintf(fpRes, "[cli](%d) Test data read error!\n", pin_host);
		return 0;
	}
    while (fgets(buffer+8, MAX_CMD_STR, filepoint_td)) {
		pin_host = pin;
		pin_network = htonl(pin);
		if(strncmp(buffer+8, "exit", 4) == 0){
			// printf("[cli](%d) \"exit\" is found!\n", pin_host);
			break;
		}
		memcpy(buffer, &pin_network, 4);
		length_host = strnlen(buffer+8, MAX_CMD_STR);
		length_network = htonl(length_host);
		memcpy(buffer+4, &length_network, 4);
		if(buffer[length_host+8-1] == '\n')
			buffer[length_host+8-1] = 0;
        write(sockfd, buffer, length_host+8);
		memset(buffer, 0, sizeof(buffer));
        read(sockfd, &pin_network, 4);
		read(sockfd, &length_network, 4);
		length_host = ntohl(length_network);
        read(sockfd, buffer, length_host);
		bprintf(fpRes,"[echo_rep](%d) %s\n", pid, buffer);
    }
	return 0;
}

int main(int argc, char* argv[])
{
	if(argc != 4){
		printf("Usage:%s <IP> <PORT> <CONCURRENT AMOUNT>\n", argv[0]);
		return 0;
	}

	struct sigaction sigact_pipe, old_sigact_pipe;
	sigact_pipe.sa_handler = sig_pipe;
	sigemptyset(&sigact_pipe.sa_mask);
	sigact_pipe.sa_flags = 0;
	sigact_pipe.sa_flags |= SA_RESTART;
	sigaction(SIGPIPE, &sigact_pipe, &old_sigact_pipe);

	struct sigaction sigact_chld, old_sigact_chld;
    sigact_chld.sa_handler = &sig_chld;
    sigemptyset(&sigact_chld.sa_mask);
    sigact_pipe.sa_flags = 0;
	sigact_pipe.sa_flags |= SA_RESTART;
    sigaction(SIGCHLD, &sigact_chld, &old_sigact_chld);

	struct sockaddr_in srv_addr;
	struct sockaddr_in cli_addr;
	int cli_addr_len;
	int connfd;
	int conc_amnt = atoi(argv[3]);
	pid_t pid = getpid();
	memset(&srv_addr, 0, sizeof(srv_addr));
	srv_addr.sin_family = AF_INET;
	inet_pton(AF_INET, argv[1], &srv_addr.sin_addr);
	srv_addr.sin_port = htons(atoi(argv[2]));

	for (int i = 0; i < conc_amnt - 1; i++) {
        if (!fork()) {
			int pin = i+1;
			char fn_res[20];
			pid = getpid();
			sprintf(fn_res, "stu_cli_res_%d.txt", pin);
        	fpRes = fopen(fn_res, "ab"); 
			if(!fpRes){
				printf("[cli](%d) child exits, failed to open file \"stu_cli_res_%d.txt\"!\n", pid, pin);
				exit(-1);
			}

			bprintf(fpRes, "[cli](%d) child process %d is created!\n", pid, pin);
			
			connfd = socket(PF_INET, SOCK_STREAM, 0);
			do{
				int res = connect(connfd, (struct sockaddr*) &srv_addr, sizeof(srv_addr));
				if(!res){
					char ip_str[20]={0};
					bprintf(fpRes, "[cli](%d) server[%s:%d] is connected!\n", pid, \
						inet_ntop(AF_INET, &srv_addr.sin_addr, ip_str, sizeof(ip_str)), \
							ntohs(srv_addr.sin_port));
					if(!echo_rqt(connfd, pin))
						break;
				}
				else
					break;	
			}while(1);
			close(connfd);
			bprintf(fpRes, "[cli](%d) connfd is closed!\n", pid);
			bprintf(fpRes, "[cli](%d) child process is going to exit!\n", pid);
			if(fpRes){
				if(!fclose(fpRes))
					printf("[cli](%d) stu_cli_res_%d.txt is closed!\n", pid, pin);
			}
			exit(1);
		}
		else{
			close(connfd);
			continue;
		}	
	}
	

	char fn_res[20];
	sprintf(fn_res, "stu_cli_res_%d.txt", 0);
    fpRes = fopen(fn_res, "wb");
	if(!fpRes){
		printf("[cli](%d) child exits, failed to open file \"stu_cli_res_0.txt\"!\n", pid);
		exit(-1);
	}
	connfd = socket(PF_INET, SOCK_STREAM, 0);
	do{
		int res = connect(connfd, (struct sockaddr*) &srv_addr, sizeof(srv_addr));
		if(!res){
			char ip_str[20]={0};
			bprintf(fpRes, "[cli](%d) server[%s:%d] is connected!\n", pid, inet_ntop(AF_INET, &srv_addr.sin_addr, ip_str, sizeof(ip_str)), ntohs(srv_addr.sin_port));
			if(!echo_rqt(connfd, 0))
				break;
		}
		else
			break;
	}while(1);
	close(connfd);
	bprintf(fpRes, "[cli](%d) connfd is closed!\n", pid);
	bprintf(fpRes, "[cli](%d) parent process is going to exit!\n", pid);
	if(!fclose(fpRes))
		printf("[cli](%d) stu_cli_res_0.txt is closed!\n", pid);
		
	return 0;
}