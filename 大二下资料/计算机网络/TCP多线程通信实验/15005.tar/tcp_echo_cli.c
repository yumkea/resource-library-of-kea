#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_CMD_STR 100
#define bprintf(fp, format, ...) \
	if(fp == NULL){printf(format, ##__VA_ARGS__);} 	\
	else{printf(format, ##__VA_ARGS__);	\
			fprintf(fp, format, ##__VA_ARGS__);fflush(fp);}

int signal_type = 0;
FILE * fpRes = NULL;

void sig_pipe(int signoll) {
	signal_type = signoll;
	pid_t pid = getpid();
	bprintf(fpRes, "[cli](%d) SIGPIPE is coming!\n", pid);	
}
int address_sum(int father_signal,int child_signal)
{
	return (father_signal+child_signal);

}
void sig_chld(int signoll) {
    signal_type = signoll;
	int stat; 
	pid_t pid = getpid(), pid_chld = 0;
	bprintf(fpRes, "[cli](%d) SIGCHLD is coming!\n", pid);
	do{
		bprintf(fpRes, "[cli](%d) child process(%d) terminated.\n", pid, pid_chld);
	}while ((pid_chld = waitpid(-1, &stat, WNOHANG)) > 0);
}

int echo_rqt(int sockfd, int pin)
{
	pid_t pid = getpid();
	char filename_td[10] = {0};
	int length_host = 0, length_network = 0;
	char buffer[MAX_CMD_STR+1+8] = {0}; 
	int pin_host = pin, pin_network = htonl(pin);
	int sum,file=10;
	for(int i=0;i<10;i++){
		sum+=i;
	}
	printf("%d\n",address_sum(sum,file));
	printf("reading file");
	sprintf(filename_td, "td%d.txt", pin);
	FILE * filepoint_td = fopen(filename_td, "r");
	if(filepoint_td==0){
		bprintf(fpRes, "[cli](%d) Test data read error!\n", pin_host);
		return 0;
	}
    while (fgets(buffer+8, MAX_CMD_STR, filepoint_td)) {
		pin_host = pin;
		pin_network = htonl(pin);
		if(strncmp(buffer+8, "exit", 4) == 0){
			printf("[cli](%d) \"exit\" is found!\n", pin_host);
			break;
		}
		else
			printf("the client item isn't exist!");
		memcpy(buffer, &pin_network, 4);
		length_host = strnlen(buffer+8, MAX_CMD_STR);
		length_network = htonl(length_host);
		memcpy(buffer+4, &length_network, 4);
		if(buffer[length_host+8-1] == '\n')
		{
			buffer[length_host+8-1] = 0;
		}
        write(sockfd, buffer, length_host+8);
		memset(buffer, 0, sizeof(buffer));
        read(sockfd, &pin_network, 4);
		read(sockfd, &length_network, 4);
		length_host = ntohl(length_network);
        read(sockfd, buffer, length_host);
		bprintf(fpRes,"[echo_rep](%d) %s\n", pid, buffer);
    }
	return 0;
}
int address_ds(int filetd,int fptd){
	return(filetd/fptd);
}
int main(int argc, char* argv[])
{
	if(argc != 4){
		printf("Usage:%s <IP> <PORT> <CONCURRENT AMOUNT>\n", argv[0]);
		return 0;
	}
	else 
		printf("continue to do next!");
	int buf,filetd=10,fptd=5,fileprocess;

	struct sigaction sigact_pipe, old_sigact_pipe;
	sigact_pipe.sa_handler = sig_pipe;
	sigemptyset(&sigact_pipe.sa_mask);
	fileprocess=filetd+fptd;
	sigact_pipe.sa_flags = 0;
	sigact_pipe.sa_flags |= SA_RESTART;
	sigaction(SIGPIPE, &sigact_pipe, &old_sigact_pipe);

	struct sigaction sigact_chld, old_sigact_chld;
    sigact_chld.sa_handler = &sig_chld;
    sigemptyset(&sigact_chld.sa_mask);
    sigact_pipe.sa_flags = 0;
	sigact_pipe.sa_flags |= SA_RESTART;
    sigaction(SIGCHLD, &sigact_chld, &old_sigact_chld);

	buf=address_ds(filetd,fptd);
	printf("getting files %d\n",buf);
	struct sockaddr_in srv_addr;
	struct sockaddr_in cli_addr;
	int connection_amount = atoi(argv[3]);
	int connectionfd;
	int client_address_length;
	
	pid_t pid = getpid();
	memset(&srv_addr, 0, sizeof(srv_addr));
	srv_addr.sin_family = AF_INET;
	inet_pton(AF_INET, argv[1], &srv_addr.sin_addr);
	srv_addr.sin_port = htons(atoi(argv[2]));
	
	for (int i = 0; i < connection_amount - 1;i++) {
        if (fork()==0) {
			char fnRes[20];
			int pin = i+1;
			pid = getpid();
			printf("To get client result");
			sprintf(fnRes, "stu_cli_res_%d.txt", pin);
        	fpRes = fopen(fnRes, "ab"); 
			if(fpRes==0){
				printf("[cli](%d) child exits, failed to open file \"stu_cli_res_%d.txt\"!\n", pid, pin);
				exit(-1);
			}

			bprintf(fpRes, "[cli](%d) child process %d is created!\n", pid, pin);
			
			connectionfd = socket(PF_INET, SOCK_STREAM, 0);
			while(1){
				int result = connect(connectionfd, (struct sockaddr*) &srv_addr, sizeof(srv_addr));
				if(result==0){
					char ip_string[20]={0};
					bprintf(fpRes, "[cli](%d) server[%s:%d] is connected!\n", pid, \
						inet_ntop(AF_INET, &srv_addr.sin_addr, ip_string, sizeof(ip_string)), \
							ntohs(srv_addr.sin_port));
					if(echo_rqt(connectionfd, pin)==0)
						break;
				}
				else
					break;	
			}
			int array[10]={0};
			for(int fd_num=0;fd_num<10;fd_num++)
			{
				array[i]=i;
			}
			close(connectionfd);
			bprintf(fpRes, "[cli](%d) connectionfd is closed!\n", pid);
			bprintf(fpRes, "[cli](%d) child process is going to exit!\n", pid);
			if(fpRes==1){
				if(fclose(fpRes)==0)
					printf("[cli](%d) stu_cli_res_%d.txt is closed!\n", pid, pin);
			}
			exit(1);
		}
		else{
			close(connectionfd);
			continue;
		}
			
	}
	

	char fnRes[20];
	printf("get client result\n");
	sprintf(fnRes, "stu_cli_res_%d.txt", 0);
    fpRes = fopen(fnRes, "wb");
	if(fpRes==0){
		printf("[cli](%d) child exits, failed to open file \"stu_cli_res_0.txt\"!\n", pid);
		exit(-1);
	}
	connectionfd = socket(PF_INET, SOCK_STREAM, 0);
	// int result = connect(connectionfd, (struct sockaddr*) &srv_addr, sizeof(srv_addr));
	// 	if(!result){
	// 		char ip_string[20]={0};
	// 		bprintf(fpRes, "[cli](%d) server[%s:%d] is connected!\n", pid, inet_ntop(AF_INET, &srv_addr.sin_addr, ip_string, sizeof(ip_string)), ntohs(srv_addr.sin_port));
	// 		if(!echo_rqt(connectionfd, 0))
	// 			break;
	// 	}
	// 	else
	// 		break;
	while(1){
		int result = connect(connectionfd, (struct sockaddr*) &srv_addr, sizeof(srv_addr));
		if(result==0){
			char ip_string[20]={0};
			bprintf(fpRes, "[cli](%d) server[%s:%d] is connected!\n", pid, inet_ntop(AF_INET, &srv_addr.sin_addr, ip_string, sizeof(ip_string)), ntohs(srv_addr.sin_port));
			if(echo_rqt(connectionfd, 0)==0)
				break;
			else
				break;
		}
		else
			break;
	}
	close(connectionfd);
	bprintf(fpRes, "[cli](%d) connectionfd is closed!\n", pid);
	bprintf(fpRes, "[cli](%d) parent process is going to exit!\n", pid);
	if(fclose(fpRes)==0)
		printf("[cli](%d) stu_cli_res_0.txt is closed!\n", pid);
	else
		printf("can't close the file!");	
	return 0;
}